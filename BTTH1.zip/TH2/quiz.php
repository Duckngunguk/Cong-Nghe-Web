<?php
$filename = "Quiz.txt";
$data = file_get_contents($filename);

// Tách từng câu hỏi bằng dòng trống
$questions = preg_split("/\r\n\r\n|\n\n/", trim($data));

?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Quiz Test</title>
</head>
<body>
    <h2>Bài thi trắc nghiệm</h2>
    <form method="post" action="result.php">

    <?php
    $qNumber = 1;

    foreach ($questions as $q) {
        // tách theo từng dòng
        $lines = explode("\n", trim($q));

        $questionText = $lines[0]; // dòng đầu là câu hỏi
        $answers = array_slice($lines, 1, 4); // 4 dòng tiếp theo là A-D

        echo "<p><strong>$qNumber. $questionText</strong></p>";

        foreach ($answers as $ans) {
            $option = substr($ans, 0, 1); // lấy A/B/C/D
            echo "<label>
                    <input type='radio' name='q$qNumber' value='$option'>
                    $ans
                  </label><br>";
        }

        // lấy đáp án đúng
        foreach ($lines as $line) {
            if (strpos($line, "ANSWER:") === 0) {
                $correct = trim(str_replace("ANSWER:", "", $line));
                echo "<input type='hidden' name='answer$qNumber' value='$correct'>";
            }
        }

        $qNumber++;
        echo "<hr>";
    }
    ?>

    <button type="submit">Nộp bài</button>
    </form>
</body>
</html>
