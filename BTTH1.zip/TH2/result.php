<?php
$total = count($_POST) / 2;
$score = 0;

for ($i = 1; $i <= $total; $i++) {
    $user = $_POST["q$i"] ?? "";
    $correct = $_POST["answer$i"];

    if ($user == $correct) {
        $score++;
    }
}

echo "<h2>Kết quả</h2>";
echo "Bạn đúng: $score / $total";
?>
