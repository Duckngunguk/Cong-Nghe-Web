<?php
$flowers = [
    [
        "name" => "Hoa Cẩm Chướng",
        "desc" => "Loài hoa đẹp, nhiều màu sắc tượng trưng cho tình yêu và sự ái mộ.",
        "img"  => "hoadep/camchuong.webp"
    ],
    [
        "name" => "Hoa Cẩm Tú Cầu",
        "desc" => "Hoa nở thành chùm lớn, thay đổi màu theo độ pH của đất.",
        "img"  => "hoadep/camtucau.webp"
    ],
    [
        "name" => "Hoa Cúc Đại",
        "desc" => "Hoa cúc lớn, dễ trồng, phổ biến trong trang trí.",
        "img"  => "hoadep/cucdai.webp"
    ],
    [
        "name" => "Hoa Cúc Lan Nho",
        "desc" => "Hoa nhỏ, nhiều màu, thường trồng chậu trang trí sân vườn.",
        "img"  => "hoadep/cuclanho.webp"
    ],
    [
        "name" => "Hoa Dạ Yến Thảo",
        "desc" => "Loại hoa mềm mại, nhiều màu đẹp mắt, thích hợp trồng chậu treo.",
        "img"  => "hoadep/dayenthao.webp"
    ],
    [
        "name" => "Hoa Đồng Tiền",
        "desc" => "Mang ý nghĩa tài lộc, may mắn, dễ trồng.",
        "img"  => "hoadep/dongtien.webp"
    ],
    [
        "name" => "Hoa Đỗ Quyên",
        "desc" => "Loài hoa trang nhã, màu sắc nổi bật, phổ biến dịp Tết.",
        "img"  => "hoadep/doquyen.jpg"
    ],
    [
        "name" => "Hoa Dừa Cạn",
        "desc" => "Dễ sống, nở quanh năm, chịu hạn tốt.",
        "img"  => "hoadep/duacan.webp"
    ],
    [
        "name" => "Hoa Hải Đường",
        "desc" => "Loài hoa sang trọng, đẹp rực rỡ, thường trồng ngày Tết.",
        "img"  => "hoadep/haiduong.jpg"
    ],
    [
        "name" => "Hoa Hồng Đèn Lồng",
        "desc" => "Giống hoa leo, cánh nhỏ màu rực rỡ.",
        "img"  => "hoadep/hoadenlong.webp"
    ],
    [
        "name" => "Hoa Giấy",
        "desc" => "Hoa leo phổ biến, dễ trồng, nhiều màu, nở quanh năm.",
        "img"  => "hoadep/hoagiay.webp"
    ],
    [
        "name" => "Hoa Sen",
        "desc" => "Quốc hoa Việt Nam, thuần khiết và thanh tao.",
        "img"  => "hoadep/hoasen.webp"
    ],
    [
        "name" => "Hoa Thanh Tú",
        "desc" => "Loài hoa có màu sắc nổi bật, ít gặp.",
        "img"  => "hoadep/hoathanhtu.webp"
    ],
    [
        "name" => "Hoa Huỳnh Anh",
        "desc" => "Hoa màu vàng rực, thường được trồng làm cảnh.",
        "img"  => "hoadep/huynhanh.webp"
    ],
    [
        "name" => "Hoa Mai",
        "desc" => "Biểu tượng ngày Tết miền Nam, màu vàng rực rỡ.",
        "img"  => "hoadep/mai.jpg"
    ],
    [
        "name" => "Hoa Păng Xê",
        "desc" => "Hoa nhỏ, cánh nhiều màu độc đáo, nở mùa mát.",
        "img"  => "hoadep/pangxe.webp"
    ],
    [
        "name" => "Hoa Sư Quân Tử",
        "desc" => "Loài hoa thủy sinh đẹp, dễ trồng trong hồ nhỏ.",
        "img"  => "hoadep/suquantu.webp"
    ],
    [
        "name" => "Hoa Tường Vy",
        "desc" => "Hoa leo, cánh mềm, nở nhiều vào mùa hè.",
        "img"  => "hoadep/tuongvy.jpg"
    ]
];
