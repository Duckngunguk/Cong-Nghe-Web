<?php
include "datahoa.php";

// Lấy chế độ hiển thị
$view = isset($_GET["view"]) ? $_GET["view"] : "guest";
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Danh sách hoa</title>
    <style>
        body { font-family: Arial; padding: 20px; background: #f4f4f4; }
        .grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(220px, 1fr)); gap: 16px; }
        .card { background: white; padding: 10px; border-radius: 8px; box-shadow: 0 0 8px #ccc; }
        .card img { width: 100%; height: 150px; object-fit: cover; border-radius: 5px; }
        table { width: 100%; border-collapse: collapse; background: white; }
        th, td { padding: 10px; border: 1px solid #ddd; }
        th { background: #eee; }
        .top { margin-bottom: 20px; }
        a.button { padding: 8px 12px; background: #1e90ff; color: white; text-decoration: none; border-radius: 6px; }
    </style>
</head>

<body>

<div class="top">
    <?php if ($view == "guest"): ?>
        <a class="button" href="index.php?view=admin">Chuyển sang Admin</a>
    <?php else: ?>
        <a class="button" href="index.php?view=guest">Chuyển sang Guest</a>
    <?php endif; ?>
</div>

<?php if ($view == "guest"): ?>

    <h2>14 loài hoa tuyệt đẹp (Chế độ Khách)</h2>
    <div class="grid">
        <?php foreach ($flowers as $f): ?>
            <div class="card">
                <img src="images/<?= $f['img'] ?>" alt="">
                <h3><?= $f['name'] ?></h3>
                <p><?= $f['desc'] ?></p>
            </div>
        <?php endforeach; ?>
    </div>

<?php else: ?>

    <h2>Quản trị – Bảng dữ liệu hoa</h2>

    <table>
        <tr>
            <th>#</th>
            <th>Ảnh</th>
            <th>Tên</th>
            <th>Mô tả</th>
            <th>Hành động</th>
        </tr>

        <?php foreach ($flowers as $i => $f): ?>
            <tr>
                <td><?= $i + 1 ?></td>
                <td><img src="images/<?= $f['img'] ?>" width="80"></td>
                <td><?= $f['name'] ?></td>
                <td><?= $f['desc'] ?></td>
                <td>
                    <a href="#" style="color: blue">Sửa</a> |
                    <a href="#" style="color: red">Xóa</a>
                </td>
            </tr>
        <?php endforeach; ?>

    </table>

<?php endif; ?>

</body>
</html>
