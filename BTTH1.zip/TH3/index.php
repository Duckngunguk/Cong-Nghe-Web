<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Đọc file CSV</title>
    <style>
        table {
            border-collapse: collapse;
            width: 100%;
        }
        th, td {
            border: 1px solid #333;
            padding: 8px;
            text-align: left;
        }
        th {
            background: #ddd;
        }
    </style>
</head>
<body>

<h2>Danh sách tài khoản từ CSV</h2>

<?php
$filename = "65HTTT_Danh_sach_diem_danh.csv";   // đổi tên nếu file bạn khác

if (!file_exists($filename)) {
    echo "<p style='color:red'>Không tìm thấy file CSV!</p>";
    exit;
}

if (($handle = fopen($filename, "r")) !== FALSE) {
    echo "<table>";
    $row = 0;

    while (($data = fgetcsv($handle, 1000, ",")) !== FALSE) {
        // Dòng đầu là tiêu đề
        if ($row == 0) {
            echo "<tr>";
            foreach ($data as $header) {
                echo "<th>" . htmlspecialchars($header) . "</th>";
            }
            echo "</tr>";
        } else {
            echo "<tr>";
            foreach ($data as $value) {
                echo "<td>" . htmlspecialchars($value) . "</td>";
            }
            echo "</tr>";
        }
        $row++;
    }

    echo "</table>";
    fclose($handle);
}
?>

</body>
</html>
